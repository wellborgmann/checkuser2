package com.gdf.jsonx;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;


import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private TextView Data,Dias,Tempo,Limite,Contas;
    private Button Btndata;
    private EditText Url,Usuario;


    public static final String SHARED_PREFS = "sharedPrefs";

   // String url = "http://177.67.83.190:5000/check/BR01";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Data = findViewById(R.id.data);
        Dias = findViewById(R.id.dias);
        Tempo = findViewById(R.id.tempo);
        Limite = findViewById(R.id.limite);
        Contas = findViewById(R.id.contas);

        Url = findViewById(R.id.url);
        Usuario = findViewById(R.id.usuario);

        final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String url = prefs.getString("URL", "");
        String usuario = prefs.getString("USUARIO", "");

        Url.setText(url);
        Usuario.setText(usuario);

        Btndata = findViewById(R.id.btndata);
        Btndata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data();
                String url  = Url.getText().toString();
                String usuario  = Usuario.getText().toString();

                final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("URL", url);
                editor.putString("USUARIO", usuario);
                editor.apply();

                Toast.makeText(MainActivity.this,"Carregando",Toast.LENGTH_SHORT).show();
                Vibrator vb = (Vibrator)   getSystemService(Context.VIBRATOR_SERVICE);
                vb.vibrate(50);


            }
        });

    }

    private void data(){
       // String usuario = mConfig.getPrivString(Settings.USUARIO_KEY);
      //  String url = "http://177.67.83.190:5000/check/"+usuario;
        final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);

        String u = prefs.getString("URL","");
        String usuario = prefs.getString("USUARIO","");
        String url = u+usuario;

        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {

                    String data = response.getString("expiration_date");
                    String dias = response.getString("expiration_days");
                    String tempo = response.getString("time_online");
                    String limite = response.getString("limit_connection");
                    String contas = response.getString("count_connection");

                    Data.setText("Vencimento: "+data);
                    Dias.setText("Dias: "+dias);
                    Tempo.setText("Tempo Conectado: "+tempo);
                    Limite.setText("Limite: "+limite);
                    Contas.setText("Dispositivos Conectados: "+contas);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "Erro ao carregar", Toast.LENGTH_SHORT).show();
            }
        });
        queue.add(jsonObjectRequest);
    }
}